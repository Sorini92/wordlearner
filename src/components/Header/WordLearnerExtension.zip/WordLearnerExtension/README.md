1) Open your browser, type chrome://extensions/ in the address bar and press Enter on your keyboard.
2) In the new window, click Developer Mode in the top right corner.
3) Now find the ZIP file with the extension you want to install and first download and extract it, for example using the same tool included in Windows (right click and Extract All...).
4) Return to the Chrome browser at the URL chrome://extensions/ and click on the Download unpacked extension button that appears at the top of the list.
5) Find the unpacked ZIP archive on your hard drive, select it and click Select directory in the lower right corner.
